package com.example.android.marsrealestate;

import androidx.databinding.BindingBuildInfo;

@BindingBuildInfo
public class DataBindingInfo {}
