package androidx.databinding.library.baseAdapters;

public class BR {
  public static final int _all = 0;

  public static final int property = 1;

  public static final int viewModel = 2;
}
