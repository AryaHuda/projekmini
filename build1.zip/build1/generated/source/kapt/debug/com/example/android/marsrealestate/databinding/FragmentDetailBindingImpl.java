package com.example.android.marsrealestate.databinding;
import com.example.android.marsrealestate.R;
import com.example.android.marsrealestate.BR;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import android.view.View;
@SuppressWarnings("unchecked")
public class FragmentDetailBindingImpl extends FragmentDetailBinding  {

    @Nullable
    private static final androidx.databinding.ViewDataBinding.IncludedLayouts sIncludes;
    @Nullable
    private static final android.util.SparseIntArray sViewsWithIds;
    static {
        sIncludes = null;
        sViewsWithIds = null;
    }
    // views
    @NonNull
    private final android.widget.ScrollView mboundView0;
    // variables
    // values
    // listeners
    // Inverse Binding Event Handlers

    public FragmentDetailBindingImpl(@Nullable androidx.databinding.DataBindingComponent bindingComponent, @NonNull View root) {
        this(bindingComponent, root, mapBindings(bindingComponent, root, 4, sIncludes, sViewsWithIds));
    }
    private FragmentDetailBindingImpl(androidx.databinding.DataBindingComponent bindingComponent, View root, Object[] bindings) {
        super(bindingComponent, root, 3
            , (android.widget.ImageView) bindings[1]
            , (android.widget.TextView) bindings[3]
            , (android.widget.TextView) bindings[2]
            );
        this.mainPhotoImage.setTag(null);
        this.mboundView0 = (android.widget.ScrollView) bindings[0];
        this.mboundView0.setTag(null);
        this.priceValueText.setTag(null);
        this.propertyTypeText.setTag(null);
        setRootTag(root);
        // listeners
        invalidateAll();
    }

    @Override
    public void invalidateAll() {
        synchronized(this) {
                mDirtyFlags = 0x10L;
        }
        requestRebind();
    }

    @Override
    public boolean hasPendingBindings() {
        synchronized(this) {
            if (mDirtyFlags != 0) {
                return true;
            }
        }
        return false;
    }

    @Override
    public boolean setVariable(int variableId, @Nullable Object variable)  {
        boolean variableSet = true;
        if (BR.viewModel == variableId) {
            setViewModel((com.example.android.marsrealestate.detail.DetailViewModel) variable);
        }
        else {
            variableSet = false;
        }
            return variableSet;
    }

    public void setViewModel(@Nullable com.example.android.marsrealestate.detail.DetailViewModel ViewModel) {
        this.mViewModel = ViewModel;
        synchronized(this) {
            mDirtyFlags |= 0x8L;
        }
        notifyPropertyChanged(BR.viewModel);
        super.requestRebind();
    }

    @Override
    protected boolean onFieldChange(int localFieldId, Object object, int fieldId) {
        switch (localFieldId) {
            case 0 :
                return onChangeViewModelDisplayPropertyType((androidx.lifecycle.LiveData<java.lang.String>) object, fieldId);
            case 1 :
                return onChangeViewModelSelectedProperty((androidx.lifecycle.LiveData<com.example.android.marsrealestate.network.MarsProperty>) object, fieldId);
            case 2 :
                return onChangeViewModelDisplayPropertyPrice((androidx.lifecycle.LiveData<java.lang.String>) object, fieldId);
        }
        return false;
    }
    private boolean onChangeViewModelDisplayPropertyType(androidx.lifecycle.LiveData<java.lang.String> ViewModelDisplayPropertyType, int fieldId) {
        if (fieldId == BR._all) {
            synchronized(this) {
                    mDirtyFlags |= 0x1L;
            }
            return true;
        }
        return false;
    }
    private boolean onChangeViewModelSelectedProperty(androidx.lifecycle.LiveData<com.example.android.marsrealestate.network.MarsProperty> ViewModelSelectedProperty, int fieldId) {
        if (fieldId == BR._all) {
            synchronized(this) {
                    mDirtyFlags |= 0x2L;
            }
            return true;
        }
        return false;
    }
    private boolean onChangeViewModelDisplayPropertyPrice(androidx.lifecycle.LiveData<java.lang.String> ViewModelDisplayPropertyPrice, int fieldId) {
        if (fieldId == BR._all) {
            synchronized(this) {
                    mDirtyFlags |= 0x4L;
            }
            return true;
        }
        return false;
    }

    @Override
    protected void executeBindings() {
        long dirtyFlags = 0;
        synchronized(this) {
            dirtyFlags = mDirtyFlags;
            mDirtyFlags = 0;
        }
        androidx.lifecycle.LiveData<java.lang.String> viewModelDisplayPropertyType = null;
        androidx.lifecycle.LiveData<com.example.android.marsrealestate.network.MarsProperty> viewModelSelectedProperty = null;
        com.example.android.marsrealestate.network.MarsProperty viewModelSelectedPropertyGetValue = null;
        java.lang.String viewModelDisplayPropertyPriceGetValue = null;
        java.lang.String viewModelSelectedPropertyImgSrcUrl = null;
        com.example.android.marsrealestate.detail.DetailViewModel viewModel = mViewModel;
        androidx.lifecycle.LiveData<java.lang.String> viewModelDisplayPropertyPrice = null;
        java.lang.String viewModelDisplayPropertyTypeGetValue = null;

        if ((dirtyFlags & 0x1fL) != 0) {


            if ((dirtyFlags & 0x19L) != 0) {

                    if (viewModel != null) {
                        // read viewModel.displayPropertyType
                        viewModelDisplayPropertyType = viewModel.getDisplayPropertyType();
                    }
                    updateLiveDataRegistration(0, viewModelDisplayPropertyType);


                    if (viewModelDisplayPropertyType != null) {
                        // read viewModel.displayPropertyType.getValue()
                        viewModelDisplayPropertyTypeGetValue = viewModelDisplayPropertyType.getValue();
                    }
            }
            if ((dirtyFlags & 0x1aL) != 0) {

                    if (viewModel != null) {
                        // read viewModel.selectedProperty
                        viewModelSelectedProperty = viewModel.getSelectedProperty();
                    }
                    updateLiveDataRegistration(1, viewModelSelectedProperty);


                    if (viewModelSelectedProperty != null) {
                        // read viewModel.selectedProperty.getValue()
                        viewModelSelectedPropertyGetValue = viewModelSelectedProperty.getValue();
                    }


                    if (viewModelSelectedPropertyGetValue != null) {
                        // read viewModel.selectedProperty.getValue().imgSrcUrl
                        viewModelSelectedPropertyImgSrcUrl = viewModelSelectedPropertyGetValue.getImgSrcUrl();
                    }
            }
            if ((dirtyFlags & 0x1cL) != 0) {

                    if (viewModel != null) {
                        // read viewModel.displayPropertyPrice
                        viewModelDisplayPropertyPrice = viewModel.getDisplayPropertyPrice();
                    }
                    updateLiveDataRegistration(2, viewModelDisplayPropertyPrice);


                    if (viewModelDisplayPropertyPrice != null) {
                        // read viewModel.displayPropertyPrice.getValue()
                        viewModelDisplayPropertyPriceGetValue = viewModelDisplayPropertyPrice.getValue();
                    }
            }
        }
        // batch finished
        if ((dirtyFlags & 0x1aL) != 0) {
            // api target 1

            com.example.android.marsrealestate.BindingAdaptersKt.bindImage(this.mainPhotoImage, viewModelSelectedPropertyImgSrcUrl);
        }
        if ((dirtyFlags & 0x1cL) != 0) {
            // api target 1

            androidx.databinding.adapters.TextViewBindingAdapter.setText(this.priceValueText, viewModelDisplayPropertyPriceGetValue);
        }
        if ((dirtyFlags & 0x19L) != 0) {
            // api target 1

            androidx.databinding.adapters.TextViewBindingAdapter.setText(this.propertyTypeText, viewModelDisplayPropertyTypeGetValue);
        }
    }
    // Listener Stub Implementations
    // callback impls
    // dirty flag
    private  long mDirtyFlags = 0xffffffffffffffffL;
    /* flag mapping
        flag 0 (0x1L): viewModel.displayPropertyType
        flag 1 (0x2L): viewModel.selectedProperty
        flag 2 (0x3L): viewModel.displayPropertyPrice
        flag 3 (0x4L): viewModel
        flag 4 (0x5L): null
    flag mapping end*/
    //end
}