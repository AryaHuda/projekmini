package com.example.android.marsrealestate.overview;

import java.lang.System;

/**
 * The [ViewModel] that is attached to the [OverviewFragment].
 */
@kotlin.Metadata(mv = {1, 1, 16}, bv = {1, 0, 3}, k = 1, d1 = {"\u0000:\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010 \n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0010\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0002\u0018\u00002\u00020\u0001B\u0005\u00a2\u0006\u0002\u0010\u0002J\u000e\u0010\u0012\u001a\u00020\u00132\u0006\u0010\u0014\u001a\u00020\u0005J\u0006\u0010\u0015\u001a\u00020\u0013J\u0010\u0010\u0016\u001a\u00020\u00132\u0006\u0010\u0017\u001a\u00020\u0018H\u0002J\u000e\u0010\u0019\u001a\u00020\u00132\u0006\u0010\u0017\u001a\u00020\u0018R\u0014\u0010\u0003\u001a\b\u0012\u0004\u0012\u00020\u00050\u0004X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u001a\u0010\u0006\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00050\u00070\u0004X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0014\u0010\b\u001a\b\u0012\u0004\u0012\u00020\t0\u0004X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0017\u0010\n\u001a\b\u0012\u0004\u0012\u00020\u00050\u000b8F\u00a2\u0006\u0006\u001a\u0004\b\f\u0010\rR\u001d\u0010\u000e\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00050\u00070\u000b8F\u00a2\u0006\u0006\u001a\u0004\b\u000f\u0010\rR\u0017\u0010\u0010\u001a\b\u0012\u0004\u0012\u00020\t0\u000b8F\u00a2\u0006\u0006\u001a\u0004\b\u0011\u0010\r\u00a8\u0006\u001a"}, d2 = {"Lcom/example/android/marsrealestate/overview/OverviewViewModel;", "Landroidx/lifecycle/ViewModel;", "()V", "_navigateToSelectedProperty", "Landroidx/lifecycle/MutableLiveData;", "Lcom/example/android/marsrealestate/network/MarsProperty;", "_properties", "", "_status", "Lcom/example/android/marsrealestate/overview/MarsApiStatus;", "navigateToSelectedProperty", "Landroidx/lifecycle/LiveData;", "getNavigateToSelectedProperty", "()Landroidx/lifecycle/LiveData;", "properties", "getProperties", "status", "getStatus", "displayPropertyDetails", "", "marsProperty", "displayPropertyDetailsComplete", "getMarsRealEstateProperties", "filter", "Lcom/example/android/marsrealestate/network/MarsApiFilter;", "updateFilter", "app_debug"})
public final class OverviewViewModel extends androidx.lifecycle.ViewModel {
    private final androidx.lifecycle.MutableLiveData<com.example.android.marsrealestate.overview.MarsApiStatus> _status = null;
    private final androidx.lifecycle.MutableLiveData<java.util.List<com.example.android.marsrealestate.network.MarsProperty>> _properties = null;
    private final androidx.lifecycle.MutableLiveData<com.example.android.marsrealestate.network.MarsProperty> _navigateToSelectedProperty = null;
    
    @org.jetbrains.annotations.NotNull()
    public final androidx.lifecycle.LiveData<com.example.android.marsrealestate.overview.MarsApiStatus> getStatus() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final androidx.lifecycle.LiveData<java.util.List<com.example.android.marsrealestate.network.MarsProperty>> getProperties() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final androidx.lifecycle.LiveData<com.example.android.marsrealestate.network.MarsProperty> getNavigateToSelectedProperty() {
        return null;
    }
    
    /**
     * Gets filtered Mars real estate property information from the Mars API Retrofit service and
     * updates the [MarsProperty] [List] and [MarsApiStatus] [LiveData]. The Retrofit service
     * returns a coroutine Deferred, which we await to get the result of the transaction.
     * @param filter the [MarsApiFilter] that is sent as part of the web server request
     */
    private final void getMarsRealEstateProperties(com.example.android.marsrealestate.network.MarsApiFilter filter) {
    }
    
    /**
     * Updates the data set filter for the web services by querying the data with the new filter
     * by calling [getMarsRealEstateProperties]
     * @param filter the [MarsApiFilter] that is sent as part of the web server request
     */
    public final void updateFilter(@org.jetbrains.annotations.NotNull()
    com.example.android.marsrealestate.network.MarsApiFilter filter) {
    }
    
    /**
     * When the property is clicked, set the [_navigateToSelectedProperty] [MutableLiveData]
     * @param marsProperty The [MarsProperty] that was clicked on.
     */
    public final void displayPropertyDetails(@org.jetbrains.annotations.NotNull()
    com.example.android.marsrealestate.network.MarsProperty marsProperty) {
    }
    
    /**
     * After the navigation has taken place, make sure navigateToSelectedProperty is set to null
     */
    public final void displayPropertyDetailsComplete() {
    }
    
    public OverviewViewModel() {
        super();
    }
}