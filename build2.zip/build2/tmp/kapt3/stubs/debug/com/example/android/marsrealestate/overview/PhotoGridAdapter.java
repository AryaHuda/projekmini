package com.example.android.marsrealestate.overview;

import java.lang.System;

/**
 * This class implements a [RecyclerView] [ListAdapter] which uses Data Binding to present [List]
 * data, including computing diffs between lists.
 */
@kotlin.Metadata(mv = {1, 1, 16}, bv = {1, 0, 3}, k = 1, d1 = {"\u00002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\u0018\u0000 \u00102\u000e\u0012\u0004\u0012\u00020\u0002\u0012\u0004\u0012\u00020\u00030\u0001:\u0003\u0010\u0011\u0012B\r\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u00a2\u0006\u0002\u0010\u0006J\u0018\u0010\u0007\u001a\u00020\b2\u0006\u0010\t\u001a\u00020\u00032\u0006\u0010\n\u001a\u00020\u000bH\u0016J\u0018\u0010\f\u001a\u00020\u00032\u0006\u0010\r\u001a\u00020\u000e2\u0006\u0010\u000f\u001a\u00020\u000bH\u0016R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082\u0004\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u0013"}, d2 = {"Lcom/example/android/marsrealestate/overview/PhotoGridAdapter;", "Landroidx/recyclerview/widget/ListAdapter;", "Lcom/example/android/marsrealestate/network/MarsProperty;", "Lcom/example/android/marsrealestate/overview/PhotoGridAdapter$MarsPropertyViewHolder;", "onClickListener", "Lcom/example/android/marsrealestate/overview/PhotoGridAdapter$OnClickListener;", "(Lcom/example/android/marsrealestate/overview/PhotoGridAdapter$OnClickListener;)V", "onBindViewHolder", "", "holder", "position", "", "onCreateViewHolder", "parent", "Landroid/view/ViewGroup;", "viewType", "DiffCallback", "MarsPropertyViewHolder", "OnClickListener", "app_debug"})
public final class PhotoGridAdapter extends androidx.recyclerview.widget.ListAdapter<com.example.android.marsrealestate.network.MarsProperty, com.example.android.marsrealestate.overview.PhotoGridAdapter.MarsPropertyViewHolder> {
    private final com.example.android.marsrealestate.overview.PhotoGridAdapter.OnClickListener onClickListener = null;
    public static final com.example.android.marsrealestate.overview.PhotoGridAdapter.DiffCallback DiffCallback = null;
    
    /**
     * Create new [RecyclerView] item views (invoked by the layout manager)
     */
    @org.jetbrains.annotations.NotNull()
    @java.lang.Override()
    public com.example.android.marsrealestate.overview.PhotoGridAdapter.MarsPropertyViewHolder onCreateViewHolder(@org.jetbrains.annotations.NotNull()
    android.view.ViewGroup parent, int viewType) {
        return null;
    }
    
    /**
     * Replaces the contents of a view (invoked by the layout manager)
     */
    @java.lang.Override()
    public void onBindViewHolder(@org.jetbrains.annotations.NotNull()
    com.example.android.marsrealestate.overview.PhotoGridAdapter.MarsPropertyViewHolder holder, int position) {
    }
    
    public PhotoGridAdapter(@org.jetbrains.annotations.NotNull()
    com.example.android.marsrealestate.overview.PhotoGridAdapter.OnClickListener onClickListener) {
        super(null);
    }
    
    /**
     * The MarsPropertyViewHolder constructor takes the binding variable from the associated
     * GridViewItem, which nicely gives it access to the full [MarsProperty] information.
     */
    @kotlin.Metadata(mv = {1, 1, 16}, bv = {1, 0, 3}, k = 1, d1 = {"\u0000\u001e\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\u0018\u00002\u00020\u0001B\r\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0002\u0010\u0004J\u000e\u0010\u0005\u001a\u00020\u00062\u0006\u0010\u0007\u001a\u00020\bR\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u000e\u00a2\u0006\u0002\n\u0000\u00a8\u0006\t"}, d2 = {"Lcom/example/android/marsrealestate/overview/PhotoGridAdapter$MarsPropertyViewHolder;", "Landroidx/recyclerview/widget/RecyclerView$ViewHolder;", "binding", "Lcom/example/android/marsrealestate/databinding/GridViewItemBinding;", "(Lcom/example/android/marsrealestate/databinding/GridViewItemBinding;)V", "bind", "", "marsProperty", "Lcom/example/android/marsrealestate/network/MarsProperty;", "app_debug"})
    public static final class MarsPropertyViewHolder extends androidx.recyclerview.widget.RecyclerView.ViewHolder {
        private com.example.android.marsrealestate.databinding.GridViewItemBinding binding;
        
        public final void bind(@org.jetbrains.annotations.NotNull()
        com.example.android.marsrealestate.network.MarsProperty marsProperty) {
        }
        
        public MarsPropertyViewHolder(@org.jetbrains.annotations.NotNull()
        com.example.android.marsrealestate.databinding.GridViewItemBinding binding) {
            super(null);
        }
    }
    
    /**
     * Custom listener that handles clicks on [RecyclerView] items.  Passes the [MarsProperty]
     * associated with the current item to the [onClick] function.
     * @param clickListener lambda that will be called with the current [MarsProperty]
     */
    @kotlin.Metadata(mv = {1, 1, 16}, bv = {1, 0, 3}, k = 1, d1 = {"\u0000\"\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0002\b\u0005\u0018\u00002\u00020\u0001B(\u0012!\u0010\u0002\u001a\u001d\u0012\u0013\u0012\u00110\u0004\u00a2\u0006\f\b\u0005\u0012\b\b\u0006\u0012\u0004\b\b(\u0007\u0012\u0004\u0012\u00020\b0\u0003\u00a2\u0006\u0002\u0010\tJ\u000e\u0010\f\u001a\u00020\b2\u0006\u0010\u0007\u001a\u00020\u0004R,\u0010\u0002\u001a\u001d\u0012\u0013\u0012\u00110\u0004\u00a2\u0006\f\b\u0005\u0012\b\b\u0006\u0012\u0004\b\b(\u0007\u0012\u0004\u0012\u00020\b0\u0003\u00a2\u0006\b\n\u0000\u001a\u0004\b\n\u0010\u000b\u00a8\u0006\r"}, d2 = {"Lcom/example/android/marsrealestate/overview/PhotoGridAdapter$OnClickListener;", "", "clickListener", "Lkotlin/Function1;", "Lcom/example/android/marsrealestate/network/MarsProperty;", "Lkotlin/ParameterName;", "name", "marsProperty", "", "(Lkotlin/jvm/functions/Function1;)V", "getClickListener", "()Lkotlin/jvm/functions/Function1;", "onClick", "app_debug"})
    public static final class OnClickListener {
        @org.jetbrains.annotations.NotNull()
        private final kotlin.jvm.functions.Function1<com.example.android.marsrealestate.network.MarsProperty, kotlin.Unit> clickListener = null;
        
        public final void onClick(@org.jetbrains.annotations.NotNull()
        com.example.android.marsrealestate.network.MarsProperty marsProperty) {
        }
        
        @org.jetbrains.annotations.NotNull()
        public final kotlin.jvm.functions.Function1<com.example.android.marsrealestate.network.MarsProperty, kotlin.Unit> getClickListener() {
            return null;
        }
        
        public OnClickListener(@org.jetbrains.annotations.NotNull()
        kotlin.jvm.functions.Function1<? super com.example.android.marsrealestate.network.MarsProperty, kotlin.Unit> clickListener) {
            super();
        }
    }
    
    /**
     * Allows the RecyclerView to determine which items have changed when the [List] of [MarsProperty]
     * has been updated.
     */
    @kotlin.Metadata(mv = {1, 1, 16}, bv = {1, 0, 3}, k = 1, d1 = {"\u0000\u0018\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0002\b\u0004\b\u0086\u0003\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0003J\u0018\u0010\u0004\u001a\u00020\u00052\u0006\u0010\u0006\u001a\u00020\u00022\u0006\u0010\u0007\u001a\u00020\u0002H\u0016J\u0018\u0010\b\u001a\u00020\u00052\u0006\u0010\u0006\u001a\u00020\u00022\u0006\u0010\u0007\u001a\u00020\u0002H\u0016\u00a8\u0006\t"}, d2 = {"Lcom/example/android/marsrealestate/overview/PhotoGridAdapter$DiffCallback;", "Landroidx/recyclerview/widget/DiffUtil$ItemCallback;", "Lcom/example/android/marsrealestate/network/MarsProperty;", "()V", "areContentsTheSame", "", "oldItem", "newItem", "areItemsTheSame", "app_debug"})
    public static final class DiffCallback extends androidx.recyclerview.widget.DiffUtil.ItemCallback<com.example.android.marsrealestate.network.MarsProperty> {
        
        @java.lang.Override()
        public boolean areItemsTheSame(@org.jetbrains.annotations.NotNull()
        com.example.android.marsrealestate.network.MarsProperty oldItem, @org.jetbrains.annotations.NotNull()
        com.example.android.marsrealestate.network.MarsProperty newItem) {
            return false;
        }
        
        @java.lang.Override()
        public boolean areContentsTheSame(@org.jetbrains.annotations.NotNull()
        com.example.android.marsrealestate.network.MarsProperty oldItem, @org.jetbrains.annotations.NotNull()
        com.example.android.marsrealestate.network.MarsProperty newItem) {
            return false;
        }
        
        private DiffCallback() {
            super();
        }
    }
}